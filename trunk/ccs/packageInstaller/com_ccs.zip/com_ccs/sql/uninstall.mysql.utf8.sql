DROP TABLE IF EXISTS `#__ccs_databases`;
DROP TABLE IF EXISTS `#__ccs_admin_fields`;