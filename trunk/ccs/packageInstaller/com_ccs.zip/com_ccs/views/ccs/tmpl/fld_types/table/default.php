<?php

echo htmlspecialchars($field_value);