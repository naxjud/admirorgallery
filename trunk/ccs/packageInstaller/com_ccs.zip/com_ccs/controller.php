<?php

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// import Joomla controller library
jimport('joomla.application.component.controller');

/**
 * General Controller of CcsController component
 */
class CcsController extends JController {

    /**
     * Method to display the view
     *
     * @access    public
     */
    function display($cachable = false, $urlparams = false) {
        parent::display();
    }

}
